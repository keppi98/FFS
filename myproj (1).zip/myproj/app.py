#from flask import Flask,render_template
from flask_mysqldb import MySQL
from flask import Flask, render_template, flash, request, url_for, redirect, session
from flask_wtf import FlaskForm, Form
from wtforms import BooleanField, TextField, PasswordField, validators, SubmitField, StringField
from MySQLdb import escape_string as thwart
import gc
from flask import g
from datetime import datetime
from datetime import date
from werkzeug.utils import secure_filename
from openpyxl import Workbook
from openpyxl import load_workbook
import os
from werkzeug.utils import secure_filename
from os import getcwd
from pathvalidate import sanitize_filename
from flask import send_file

app = Flask(__name__)

app.config['TESTING'] = True

app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config["MYSQL_DB"]='ffs'
app.config['SECRET_KEY']='SQLIDP'
mysql = MySQL(app)

@app.route("/")
def home():
    return render_template('duplicate.html')
'''
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        id = request.form['id']
        psw = request.form['password']
        c = mysql.connection.cursor()
        c.excute(select * from user1 where id=%s,(id,))
        x=c.fetchall()
        count = 0
        for k in x:
            count=count+1
        if count > 0:

        return render_template('login.html')
'''

@app.route("/about")
def about():
    return render_template("about.html")


@app.route('/index')
def index():
    if 'username' in session:
      username = session['username']
      return render_template('index.html',username=username)
'''
      return 'Logged in as ' + username + '<br>' + \
         "<b><a href = '/logout'>click here to log out</a></b>"
    return "You are not logged in <br><a href = '/login'></b>" + \
      "click here to log in</b></a>"
    return render_template('index.html')
'''
@app.route('/logout')
def logout():
   # remove the username from the session if it is there
   session.pop('username', None)
   #headers.add('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0')
   #response.headers.add('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0')
   return redirect(url_for('home'))

@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

@app.after_request
def after_this_request(func):
    if not hasattr(g, 'call_after_request'):
        g.call_after_request = []
    g.call_after_request.append(func)
    return func


@app.after_request
def per_request_callbacks(response):
    for func in getattr(g, 'call_after_request', ()):
        response = func(response)
    return response


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username_form  = request.form['id']
        password_form  = request.form['password']
        c = mysql.connection.cursor()
        c.execute('''SELECT * FROM user1 WHERE id = %s and psw= %s''', (username_form, password_form,)) # CHECKS IF USERNAME EXSIST
        x=c.fetchall()
        count = 0
        for k in x:
            count=count+1
        if count > 0:
            session['username'] = username_form
            return redirect(url_for('index'))
        else:
            error = "Invalid Credential"
            return render_template('login.html', error=error)
    else:
        return render_template('login.html')

@app.route('/viewprofile',methods=['GET','POST'])
def viewprofile():
    username = session.get('username',None)
    l = []
    x = mysql.connection.cursor()
    x.execute('select * from profiles where id=%s',[username])
    data = x.fetchall()
    k = len(data)
    if k != 0:
        l = list(data)
    else:
        l = [[username,'Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered']]
    return render_template('viewprofile.html',l=l,username=username)

@app.route('/profile',methods=['GET','POST'])
def profile():
    username=session.get('username',None)
    l = []
    x = mysql.connection.cursor()
    x.execute('select * from profiles where id=%s',[username])
    data = x.fetchall()
    k = len(data)
    x.close()
    gc.collect()
    if k != 0:
        l = list(data)
    else:
        l = [[username,'Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered']]
    x = mysql.connection.cursor()
    x.execute('''select * from profiles where id = %s ''',(username,))
    y = x.fetchall()
    x.close()
    gc.collect()
    count = 0
    for k in y:
        count = count +1
    if  count > 0:
        flash('User Profile already update')
        return render_template('updateprofile.html',username=username,l=l)
    else:
        if request.method == 'POST':
            x = mysql.connection.cursor()
            x.execute('''select * from profiles where id = %s ''',(username,))
            y = x.fetchall()
            count = 0
            for k in y:
                count =count +1
            if count > 0:
                flash("User profile already exists....!!!!")
                return redirect(url_for('index'))
            else:
                name = request.form['name']
                designation=request.form['designation']
                dob1 = request.form['dob']
                dob = datetime.strptime(dob1,"%Y-%m-%d")
                doj1 = request.form['doj']
                doj = datetime.strptime(doj1,"%Y-%m-%d")
                phone = request.form['phone']
                email = request.form['email']
                btech = request.form['btech']
        #btech = datetime.strptime(b,"%d/%m/%Y %H:%M")
        #btech = float(b)
                mtech = request.form['mtech']
        #mtech = datetime.strptime(m,"%d/%m/%Y %H:%M")
        #mtech=float(m)
                other = request.form['exp_other']
                adhar = request.form['adhar']
                pan = request.form['pan']
                c = mysql.connection.cursor()
                c.execute('insert into profiles(id,name,designation,dob,doj,phone,email,btech,mtech,exp_other,adhar,pan) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(username,name,designation,(dob.strftime('%Y-%m-%d')),(doj.strftime('%Y-%m-%d')),phone,email,btech,mtech,other,adhar,pan))
                c.connection.commit()
                c.close()
                gc.collect()
                flash("Profile successfully created......")
                return redirect(url_for('index'))
    return render_template('profile.html',username=username)

@app.route('/updateprofile', methods=['GET','POST'])
def updateprofile():
    username = session.get('username',None)
    l = [[username,'Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered','Not Entered']]
    x = mysql.connection.cursor()
    x.execute('select * from profiles where id=%s',[username])
    data = x.fetchall()
    k = len(data)
    x.close()
    gc.collect()
    l = list(data)
    if request.method == 'POST':
        select = request.form['sel']
        value = request.form['val']
        value1 = request.form['designation']
        if (select == 'none') or (select !='designation' and value == '') or (select =='designation' and value1 == ''):
            flash("please enter a valid value");
            return render_template('updateprofile.html',username=username,l=l)
        x = mysql.connection.cursor()
        if select == 'name':
            x.execute('update profiles set name=%s where id=%s',(value,username))
        elif select == 'designation':
            value = request.form['designation']
            x.execute('update profiles set designation=%s where id=%s',(value,username))
        elif select =='dob':
            x.execute('update profiles set dob=%s where id=%s',(value,username))
        elif select == 'doj':
            x.execute('update profiles set doj=%s where id=%s',(value,username))
        elif select == 'phone':
            x.execute('update profiles set phone=%s where id=%s',(value,username))
        elif select == 'email':
            x.execute('update profiles set email=%s where id=%s',(value,username))
        elif select == 'btech':
            x.execute('update profiles set btech=%s where id=%s',(value,username))
        elif select == 'mtech':
            x.execute('update profiles set mtech=%s where id=%s',(value,username))
        elif select =='exp_other':
            x.execute('update profiles set exp_other=%s where id=%s',(value,username))
        elif select == 'adhar':
            x.execute('update profiles set adhar=%s where id=%s',(value,username))
        elif select == 'pan':
            x.execute('update profiles set pan=%s where id=%s',(value,username))
        x.connection.commit()
        x.close()
        gc.collect()
        x = mysql.connection.cursor()
        x.execute('select * from profiles where id=%s',[username])
        data = x.fetchall()
        k = len(data)
        x.close()
        gc.collect()
        l = list(data)
        flash('Field value updated successfully... !!!')
        return render_template('updateprofile.html',l=l,username=username)
    else:
        return render_template('updateprofile.html',l=l,username=username)
    return render_template('updateprofile.html',l=l,username=username)


@app.route('/register',methods=['GET','POST'])
def register():
        #form = RegistrationForm()
        if request.method == 'POST':
            eid = request.form['id']
            psw = request.form['psw']
            error=None
            #id  = request.form.get()
            #psw= from.psw.data
            #password = request.form.get()#sha256_crypt.encrypt((str(form.psw.data)))
            #c = mysql.connection.cursor()
            c= mysql.connection.cursor()
            c.execute('''SELECT * FROM user1 WHERE id = %s''',(eid,))
            x=c.fetchall()
            count = 0
            for k in x:
                count=count+1
            if count > 0:
                error="USER EXISTS !!!!!"
                flash("That username is already exists......!!!!")
                return render_template('register.html')
            else:
                c.execute('''INSERT INTO user1 (id, psw) VALUES (%s, %s)''',(eid, psw))
                c.connection.commit()
                c.close()
                #conn.close()
                gc.collect()
                session['logged_in'] = True
                session['id'] = eid
                flash('User successfully created.....!')
                flash("Thanks for registering!")
                return redirect(url_for('home'))
        else:
            error = "User already exists....!!!!"
            return render_template("register.html",form=Form)

@app.route('/publications',methods=['GET','POST'])
def publications():
    username=session.get('username',None)
    if request.method == 'POST':
        select = request.form['pubsel']
        if select == 'none':
            flash('Select proper option ... !!!!')
            return render_template('publications.html',username=username)
        elif select == 'conference':
            return render_template('conference.html',username=username)
        elif select == 'journal':
            return render_template('journal.html',username=username)
        elif select == 'viewpublish':
            return render_template('viewpublish.html',username=username)
        elif select == 'delcon':
            x = mysql.connection.cursor()
            x.execute('select * from conference where id=%s',(username,))
            y = x.fetchall()
            clen = len(y)
            x.close()
            gc.collect()
            return render_template('delcon.html',username=username,y=y,clen=clen)
        elif select == 'delpub':
            x = mysql.connection.cursor()
            x.execute('select * from journal where id=%s',(username,))
            b = x.fetchall()
            jlen = len(b)
            x.close()
            gc.collect()
            return render_template('delpub.html',username=username,b=b,jlen=jlen)
    return render_template('publications.html',username=username)
